package com.example.todo;

import android.content.DialogInterface;

public interface onDialogCloseListner {

    void onDialogClose(DialogInterface dialogInterface);
}